package com.softuni.jsonexercise.domain.dtos.users;

import java.util.List;

public class UserWithProductsXmlDto {

    private List<UserWithProductsDto> users;

}
