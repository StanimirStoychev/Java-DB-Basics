package com.softuni.productshop.domain.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Set;

@NoArgsConstructor
@Getter
@Entity
@Table(name = "products")
public class Product extends BaseEntity {

    private String name;

    private BigDecimal price;

    @ManyToOne
    @Fetch(FetchMode.JOIN)
    private User buyer;

    @ManyToOne
    @Fetch(FetchMode.JOIN)
    private User seller;

    @ManyToMany
    @Fetch(FetchMode.JOIN)
    private Set<Category> categories;

    public Product(String name, BigDecimal price, User buyer, User seller) {
        setName(name);
        this.price = price;
        this.buyer = buyer;
        this.seller = seller;
    }

    public void setName(String name) {
        if(name.length() < 3) {
            throw new IllegalArgumentException("Name must be at least 3 characters!");
        }
        this.name = name;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setBuyer(User buyer) {
        this.buyer = buyer;
    }

    public void setSeller(User seller) {
        this.seller = seller;
    }
}
