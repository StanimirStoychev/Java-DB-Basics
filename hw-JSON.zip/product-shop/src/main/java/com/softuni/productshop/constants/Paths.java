package com.softuni.productshop.constants;

import java.nio.file.Path;

public enum Paths {
    ;
    public static final Path USER_JSON_PATH =
            Path.of("src", "main", "resources", "files", "users.json");

    public static final Path CATEGORY_JSON_PATH =
            Path.of("src", "main", "resources", "files", "categories.json");

    public static final Path PRODUCT_JSON_PATH =
            Path.of("src", "main", "resources", "files", "products.json");
}
