package com.softuni.productshop.domain.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.beans.factory.FactoryBeanNotInitializedException;

import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.util.Set;

@NoArgsConstructor
@Getter
@Entity
@Table(name = "categories")
public class Category extends BaseEntity{

    private String name;


    public Category(String name) {
        setName(name);
    }

    public void setName(String name) {
        if(name.length() <=3 || name.length() > 15) {
            throw new IllegalArgumentException("Name lenght must be from 3 to 15 characters!");
        }
        this.name = name;
    }
}
