package com.example.cardealer.service;

import java.io.IOException;

public interface PartService {
    void seedPart() throws IOException;
}
