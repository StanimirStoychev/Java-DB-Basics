package com.example.cardealer.service.impl;

import com.example.cardealer.Constants.Discount;
import com.example.cardealer.domain.car.Car;
import com.example.cardealer.domain.customer.Customer;
import com.example.cardealer.domain.sale.Sale;
import com.example.cardealer.domain.sale.SaleDto;
import com.example.cardealer.domain.sale.SaleWithDiscountDto;
import com.example.cardealer.repository.CarRepository;
import com.example.cardealer.repository.CustomerRepository;
import com.example.cardealer.repository.SaleRepository;
import com.example.cardealer.service.SaleService;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.*;
import java.util.stream.LongStream;

@Service
public class SaleServiceImpl implements SaleService {
    private final ModelMapper mapper;
    private final Gson gson;
    private final SaleRepository saleRepository;
    private final CarRepository carRepository;
    private final CustomerRepository customerRepository;

    @Autowired
    public SaleServiceImpl(
            ModelMapper mapper,
            Gson gson,
            SaleRepository saleRepository,
            CarRepository carRepository,
            CustomerRepository customerRepository) {
        this.mapper = mapper;
        this.gson = gson;
        this.saleRepository = saleRepository;
        this.carRepository = carRepository;
        this.customerRepository = customerRepository;
    }

    @Override
    public void seedSales() {
        if(saleRepository.count() == 0) {
            final Random random = new Random();

            long high = this.carRepository.count();

            final long numberOfSales = random.nextLong(high);

            final List<Sale> sales = new ArrayList<>();
            Set<Car> saleCars = new HashSet<>();

            LongStream.range(0, numberOfSales)
                    .forEach(number -> {
                        Car car = this.carRepository.getRandomEntity().orElseThrow(NoSuchElementException::new);

                        while (saleCars.contains(car)){
                            car = this.carRepository.getRandomEntity().orElseThrow(NoSuchElementException::new);
                        }

                        saleCars.add(car);

                        Customer customer = this.customerRepository.getRandomEntity().orElseThrow(NoSuchElementException::new);

                        Integer discount = Discount.getDiscount();

                        Sale newSale = new Sale(discount, car, customer);
                        sales.add(newSale);
                    });

            this.saleRepository.saveAllAndFlush(sales);
        }
    }

    @Override
    @Transactional
    public List<SaleWithDiscountDto> getAllSalesWithDiscount() {
        return this.saleRepository
                .findAll()
                .stream()
                .map(sale -> mapper.map(sale, SaleDto.class))
                .map(SaleDto::saleWithDiscountDto)
                .toList();
    }
}
