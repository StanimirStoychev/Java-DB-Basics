package com.example.cardealer.service;

import com.example.cardealer.domain.customer.CustomerOrderBirthdateDto;
import com.example.cardealer.domain.customer.CustomerTotalSalesDto;

import java.io.IOException;
import java.util.List;

public interface CustomerService {
    void seedCustomers() throws IOException;

    List<CustomerOrderBirthdateDto> getAllCustomers();

    List<CustomerTotalSalesDto> getAllWithTotalSales();
}
