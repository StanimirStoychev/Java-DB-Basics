package com.example.cardealer.service;

import com.example.cardealer.domain.sale.SaleWithDiscountDto;

import java.util.List;

public interface SaleService {
    void seedSales();

    List<SaleWithDiscountDto> getAllSalesWithDiscount();
}
