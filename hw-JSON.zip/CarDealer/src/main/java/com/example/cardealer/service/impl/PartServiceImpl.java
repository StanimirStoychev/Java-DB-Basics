package com.example.cardealer.service.impl;

import com.example.cardealer.Constants.PathFiles;
import com.example.cardealer.domain.part.Part;
import com.example.cardealer.domain.part.PartImportDto;
import com.example.cardealer.domain.supplier.Supplier;
import com.example.cardealer.repository.PartRepository;
import com.example.cardealer.repository.SupplierRepository;
import com.example.cardealer.service.PartService;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class PartServiceImpl implements PartService {
    private final PartRepository partRepository;
    private final SupplierRepository supplierRepository;
    private final ModelMapper mapper;
    private final Gson gson;

    @Autowired
    public PartServiceImpl(
            PartRepository partRepository,
            SupplierRepository supplierRepository,
            ModelMapper mapper,
            Gson gson) {
        this.partRepository = partRepository;
        this.supplierRepository = supplierRepository;
        this.mapper = mapper;
        this.gson = gson;
    }

    @Override
    public void seedPart() throws IOException {
        if(partRepository.count() == 0){
            final FileReader fileReader = new FileReader(PathFiles.PARTS_FILE_PATH.toFile());

            final List<Part> parts = Arrays.stream(gson.fromJson(fileReader, PartImportDto[].class))
                    .map(partImportDto -> mapper.map(partImportDto, Part.class))
                    .map(this::setRandomSupplier)
                    .toList();

            fileReader.close();

            this.partRepository.saveAllAndFlush(parts);
        }

    }

    private Supplier getRandomSupplier() {
        return this.supplierRepository.getRandomEntity().orElseThrow(NoSuchElementException::new);
    }

    private Part setRandomSupplier(Part part) {

        final Supplier supplier = getRandomSupplier();

        part.setSupplier(supplier);

        return part;
    }
}