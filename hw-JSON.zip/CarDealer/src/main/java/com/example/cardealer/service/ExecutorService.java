package com.example.cardealer.service;

import java.io.IOException;

public interface ExecutorService {
    String executeCommand() throws IOException;
}
