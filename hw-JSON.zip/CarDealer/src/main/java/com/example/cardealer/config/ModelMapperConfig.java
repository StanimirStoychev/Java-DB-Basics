package com.example.cardealer.config;

import com.example.cardealer.domain.customer.Customer;
import com.example.cardealer.domain.customer.CustomerOrderBirthdateDto;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Configuration
public class ModelMapperConfig {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper mapper = new ModelMapper();

        return mapper;
    }

    private void customerToCustomerOrderBirthdateDto(ModelMapper mapper) {
        Converter<LocalDateTime, String> toDateToString =
                ctx -> DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(ctx.getSource());

        mapper.createTypeMap(Customer.class, CustomerOrderBirthdateDto.class)
                .addMapping(Customer::getBirthDate, CustomerOrderBirthdateDto::setBirthDate)
                .addMapping(Customer::getSales, CustomerOrderBirthdateDto::setSales);
    }
}