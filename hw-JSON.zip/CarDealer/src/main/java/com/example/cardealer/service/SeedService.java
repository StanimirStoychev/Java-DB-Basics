package com.example.cardealer.service;

import java.io.IOException;

public interface SeedService {
    void seedData() throws IOException;
}
